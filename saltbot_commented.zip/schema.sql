-- users table
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id TEXT UNIQUE NOT NULL,
    username TEXT NOT NULL,
    salt REAL NOT NULL DEFAULT 0
);

-- daily salt history
CREATE TABLE IF NOT EXISTS salt_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    salt_change REAL NOT NULL,
    UNIQUE(user_id, date),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ranks table
CREATE TABLE IF NOT EXISTS ranks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    threshold REAL NOT NULL
);

-- default ranks
INSERT OR IGNORE INTO ranks (name, threshold) VALUES ('Sugar Babe',0);
INSERT OR IGNORE INTO ranks (name, threshold) VALUES ('Salt Peasant',10);
INSERT OR IGNORE INTO ranks (name, threshold) VALUES ('Salty Sweet',100);
INSERT OR IGNORE INTO ranks (name, threshold) VALUES ('Salt Queen',300);
INSERT OR IGNORE INTO ranks (name, threshold) VALUES ('Salt King',500);

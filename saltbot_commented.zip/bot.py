import discord
from discord.ext import commands
from config import DISCORD_TOKEN
from database import init_db
import commands as cmd

init_db()
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"✅ SaltBot is online as {bot.user}")

@bot.event
async def on_message(message: discord.Message):
    await cmd.process_message(message)
    await bot.process_commands(message)

@bot.command()
async def mysalt(ctx: commands.Context):
    await cmd.mysalt(ctx)

@bot.command()
async def setsalt(ctx: commands.Context, member: discord.Member, value: float):
    await cmd.setsalt(ctx, member, value)

@bot.command()
async def saltboardtoday(ctx: commands.Context):
    await cmd.saltboardtoday(ctx)

@bot.command()
async def saltboardweek(ctx: commands.Context):
    await cmd.saltboardweek(ctx)

@bot.command(name="saltbothelp")
async def saltbothelp(ctx: commands.Context):
    await cmd.saltbothelp(ctx)

if not DISCORD_TOKEN:
    raise RuntimeError("DISCORD_TOKEN not found. Set it in your environment or .env file.")
bot.run(DISCORD_TOKEN)

import discord
from discord.ext import commands
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import regex as re
from database import update_salt, get_rank_for_salt, get_leaderboard, get_or_create_user, set_user_salt

analyzer = SentimentIntensityAnalyzer()
CURSE_WORDS = {"damn", "hell", "shit", "fuck", "bastard", "crap", "bitch"}
INSULT_WORDS = {"idiot", "stupid", "moron", "loser", "jerk"}
NEGATIVITY_THRESHOLD = -0.3
PENALTY_CURSE = 2.0
PENALTY_INSULT = 5.0
FUZZY_ERRORS = 1

def build_fuzzy_regex(words, max_errors=1):
    if not words:
        return None
    pattern = "|".join(rf"(?b){re.escape(w)}{{e<={max_errors}}}" for w in sorted(words, key=len, reverse=True))
    return re.compile(pattern, re.IGNORECASE)

CURSE_RX = build_fuzzy_regex(CURSE_WORDS, FUZZY_ERRORS)
INSULT_RX = build_fuzzy_regex(INSULT_WORDS, FUZZY_ERRORS)

async def process_message(message: discord.Message):
    if message.author.bot:
        return
    text = message.content
    scores = analyzer.polarity_scores(text)
    compound = scores["compound"]
    curse_found = bool(CURSE_RX.search(text)) if CURSE_RX else False
    insult_found = bool(INSULT_RX.search(text)) if INSULT_RX else False
    directed = len(message.mentions) > 0
    penalty = 0.0
    if curse_found or insult_found:
        if insult_found or (curse_found and (compound < NEGATIVITY_THRESHOLD or directed)):
            penalty = PENALTY_INSULT
        else:
            penalty = PENALTY_CURSE
    if penalty > 0:
        update_salt(str(message.author.id), message.author.name, penalty)
        await message.channel.send(f"⚠️ {message.author.mention} gained **{penalty:.0f}** salt.")

async def mysalt(ctx: commands.Context):
    _, total = get_or_create_user(str(ctx.author.id), ctx.author.name)
    rank = get_rank_for_salt(total)
    await ctx.send(f"🧂 {ctx.author.mention}, your salt is **{total:.2f}** — Rank: **{rank}**")

async def setsalt(ctx: commands.Context, member: discord.Member, value: float):
    if not ctx.author.guild_permissions.administrator:
        await ctx.send("⛔ You need administrator permissions to use this command.")
        return
    set_user_salt(str(member.id), member.name, float(value))
    await ctx.send(f"✅ Set {member.mention}'s salt to **{value:.2f}**")

async def saltboardtoday(ctx: commands.Context):
    lb = get_leaderboard("today")
    if not lb:
        await ctx.send("😇 No salt recorded today.")
        return
    lines = [f"{i+1}. {name} — {score:.2f}" for i, (name, score) in enumerate(lb)]
    await ctx.send("📅 **Today's Salt Leaderboard (UTC)**\n" + "\n".join(lines))

async def saltboardweek(ctx: commands.Context):
    lb = get_leaderboard("week")
    if not lb:
        await ctx.send("😇 No salt recorded this week.")
        return
    lines = [f"{i+1}. {name} — {score:.2f}" for i, (name, score) in enumerate(lb)]
    await ctx.send("📆 **This Week's Salt Leaderboard (UTC)**\n" + "\n".join(lines))

async def saltbothelp(ctx: commands.Context):
    help_text = (
        "**🧂 SaltBot Help & Rules**\n"
        "- Mild cursing: +2 salt\n"
        "- Insults or cursing with negative sentiment / @mention: +5 salt\n"
        "- One daily history entry per user (UTC).\n\n"
        "**Commands:**\n"
        "• `!mysalt` — Show your salt and rank\n"
        "• `!setsalt @user <value>` — (Admin) Set a user's salt\n"
        "• `!saltboardtoday` — Today's leaderboard (UTC)\n"
        "• `!saltboardweek` — This week's leaderboard (UTC)\n"
        "• `!saltbothelp` — Show this help message"
    )
    await ctx.send(help_text)

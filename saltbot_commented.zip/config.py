import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Discord bot token (read from environment)
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")

# SQLite database file path
DATABASE_PATH = "saltbot.db"

# Default rank thresholds (editable via DB)
DEFAULT_RANKS = [
    ("Sugar Babe", 0),
    ("Salt Peasant", 10),
    ("Salty Sweet", 100),
    ("Salt Queen", 300),
    ("Salt King", 500),
]
